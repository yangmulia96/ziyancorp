# 🎬 AI UGC & Influencer Prompt Playbook (Master Edition)
**Katalog Komprehensif Prompt Video Kreator Berbasis Proyek Google Flow (Labs FX)**  
*Disusun oleh ZiyanCorp Digital Assets*

---

## 📑 DAFTAR ISI PLAYBOOK

### 👟 BAGIAN 1: Fashion & Footwear UGC (Sepatu, Apparel & Model)
* [Skenario 01: DESGL Casual Footwear Unboxing & First Look](#skenario-01-desgl-casual-footwear-unboxing--first-look)
* [Skenario 02: Streetwear Fashion Lookbook Reel](#skenario-02-streetwear-fashion-lookbook-reel)
* [Skenario 03: Walking Pad Footwear Flexibility & Cushion Test](#skenario-03-walking-pad-footwear-flexibility--cushion-test)
* [Skenario 04: Urban Sneakers Step & Street Lifestyle](#skenario-04-urban-sneakers-step--street-lifestyle)
* [Skenario 05: Female Casual Outfit Mirror Selfie & Studio Transition](#skenario-05-female-casual-outfit-mirror-selfie--studio-transition)

### ⌚ BAGIAN 2: Gadget, Tech & Luxury Accessories
* [Skenario 06: Smartwatch AMOLED Dial & Strap Luxury Detail](#skenario-06-smartwatch-amoled-dial--strap-luxury-detail)
* [Skenario 07: Wireless Clip-on Mic & Creator Audio Test](#skenario-07-wireless-clip-on-mic--creator-audio-test)
* [Skenario 08: Premium Eyewear & Glasses Face Framing](#skenario-08-premium-eyewear--glasses-face-framing)

### 🚗 BAGIAN 3: Auto-Care, ASMR & Technical Actions
* [Skenario 09: Car Hood Paint Restoration & Mirror Finish](#skenario-09-car-hood-paint-restoration--mirror-finish)
* [Skenario 10: Precision Spray Coating & Workshop Action](#skenario-10-precision-spray-coating--workshop-action)

### 🎙️ BAGIAN 4: Content Creator, Podcast & Talking Head
* [Skenario 11: Podcast Studio Talking Head & Revenue Breakdown](#skenario-11-podcast-studio-talking-head--revenue-breakdown)
* [Skenario 12: Digital Product Affiliate Laptop Showcase](#skenario-12-digital-product-affiliate-laptop-showcase)

---

## 👟 BAGIAN 1: FASHION & FOOTWEAR UGC

### Skenario 01: DESGL Casual Footwear Unboxing & First Look

* **Judul & Kategori Konten:** "DESGL Casual Footwear Unboxing & First Look" — Kategori Fashion & Footwear UGC
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Box sepatu warna hitam minimalis dengan logo tulisan putih tegas bertuliskan "DESGL", berisi sepasang sneakers casual model low-top bertali putih.
  * **Referensi 2 (Persona Model):** Pemuda Indonesia usia 22–26 tahun, berambut rapi, mengenakan kaos polos hitam katun, terpasang wireless clip-on mic di kerah baju, ekspresi ramah dan antusias khas konten kreator TikTok.
* **Master Action Prompt:**
  ```text
  [0.0s-3.0s: Eye-level medium close-up, handheld iPhone 15 Pro aesthetic, 9:16 vertical] Young Indonesian male content creator sitting in a cozy bedroom studio with warm ambient backlighting. He smiles warmly directly at the camera, holding a black box labeled 'DESGL' and tapping the lid with his finger.
  [Jump cut to 3.0s-6.5s: Dynamic push-in close-up shot] He smoothly lifts open the box lid towards the camera, pulling out the fresh casual sneakers. He turns the shoe 45 degrees to highlight the clean side-profile, textured rubber outsole, and premium stitching details with natural hand movement.
  [Jump cut to 6.5s-10.0s: Slight low-angle tilt-up shot] He brings the shoe close to the lens with an approving nod, pointing downward with his index finger toward the bottom-left corner with a confident, persuasive smile. Natural handheld motion breathing, crisp 4k 60fps, photorealistic creator look.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/cbfa61b1-c10e-40f7-a989-70446ff2ebae](https://labs.google/fx/tools/flow/shared/video/cbfa61b1-c10e-40f7-a989-70446ff2ebae)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Jujur, ini sneakers 100 ribuan tapi vibenya berasa kayak sejutaan!"*  
    📌 **Teks Layar:** `UNBOXING RACUN BARU! 😱👟`
  * `3.0s – 6.5s (Demo Fitur):` *"Solnya udah empuk karet anti-licin, bahannya gak bikin lecet, plus jahitannya super rapi!"*  
    📌 **Badge Layar:** `[⭐ SOL RINGAN + ANTI-SLIP]`
  * `6.5s – 10.0s (CTA):` *"Mumpung promo bundling masih ada, langsung amankan sebelum kehabisan di keranjang kuning!"*  
    📌 **Grafis:** `[👇 KLIK KERANJANG KUNING DI SINI (Diskon 50%)]` *(Panah Berkedip)*
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 02: Streetwear Fashion Lookbook Reel

* **Judul & Kategori Konten:** "Streetwear Fashion Lookbook Reel" — Kategori Fashion & Apparel Lookbook
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Setelan pakaian oversized streetwear / outfit kasual harian dengan palet warna earthy/monochrome, lipatan kain natural dengan detail tekstur kain katun premium.
  * **Referensi 2 (Persona Model):** Model wanita/pria muda Indonesia berpenampilan modern chic, makeup natural dewy, gaya berjalan percaya diri dan elegan.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Tracking gimbal push-in shot, full body vertical 9:16] A stylish Indonesian model walking confidently towards the camera down a bright modern outdoor urban walkway with soft golden-hour sunlight flare. Fabric moves gracefully with realistic air resistance.
  [Jump cut to 3.5s-7.0s: Medium side-profile tracking shot] Quick outfit pivot turn, showcasing the back silhouette and sleeve proportions. Smooth natural smile, hair gently blowing in the soft breeze.
  [Jump cut to 7.0s-10.0s: Close-up bust shot] Model pauses, glances into the camera lens with confident expression, adjusting collar with fingers. Ultra-clean commercial grade lighting, Hasselblad 85mm f/1.8 optical blur, 4k 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/77c86804-c8cc-47cc-ab2e-116c7e2339de](https://labs.google/fx/tools/flow/shared/video/77c86804-c8cc-47cc-ab2e-116c7e2339de)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Outfit simpel yang bikin lo auto keliatan mahal tanpa bikin kantong bolong!"*  
    📌 **Teks Layar:** `OUTFIT NGAMPUS / NONGKRONG SIMPLE 🖤`
  * `3.0s – 6.5s (Demo Fitur):` *"Cuttingan oversized-nya pas banget di badan, bahannya adem dan gak gampang lecek!"*  
    📌 **Badge Layar:** `[⚡ 100% COTTON COMBED - ADEM SEHARIAN]`
  * `6.5s – 10.0s (CTA):` *"Yuk upgrade gaya lo hari ini, klik keranjang kuning buat klaim gratis ongkir!"*  
    📌 **Grafis:** `[🛍️ AMBIL VOUCHER GRATIS ONGKIR SEKARANG]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 03: Walking Pad Footwear Flexibility & Cushion Test

* **Judul & Kategori Konten:** "Walking Pad Footwear Flexibility & Cushion Test" — Kategori Footwear & Sportswear
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Sepatu slip-on / sneakers running fleksibel berwarna netral dengan sol elastis bertekstur honeycomb.
  * **Referensi 2 (Persona Model):** Kaki model mengenakan celana jogger slim-fit rapi dan kaos kaki semata kaki, beraktivitas di atas treadmill tipis / walking pad indoor.
* **Master Action Prompt:**
  ```text
  [0.0s-3.0s: Extreme close-up macro angle, ground level, 9:16] Model's hands effortlessly sliding foot into the sneaker on a soft designer living room rug. Crisp sound visual cues, detailed shoe collar stretching smoothly around ankle.
  [Jump cut to 3.0s-7.0s: Low-angle side tracking tracking shot] Feet stepping smoothly and rhythmically onto an active slim walking pad. Realistic sole cushioning compression, natural shoe bending at the toe box with zero resistance.
  [Jump cut to 7.0s-10.0s: Top-down 45-degree angle] Feet pivoting smoothly, demonstrating the lightweight balance. Cinematic studio softbox illumination, hyper-realistic shoe leather and knit mesh texture, 60fps slow-motion fluidity.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/9f6f65cd-c76e-4233-9967-53a11127cf90](https://labs.google/fx/tools/flow/shared/video/9f6f65cd-c76e-4233-9967-53a11127cf90)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Capek pakai sepatu yang kaku dan bikin kaki pegel pas jalan jauh?"*  
    📌 **Teks Layar:** `UJI KELENTURAN SEPATU VIRAL 🔥`
  * `3.0s – 6.5s (Demo Fitur):` *"Lihat kelenturannya! Bener-bener seringan kapas dan ngikutin lekuk kaki saat jalan."*  
    📌 **Badge Layar:** `[☁️ MEMORY FOAM SOLE - ULTRA LIGHT]`
  * `6.5s – 10.0s (CTA):` *"Ready semua ukuran, checkout sekarang di keranjang kuning sebelum kehabisan size lo!"*  
    📌 **Grafis:** `[👉 PILIH UKURAN & WARNA DI KERANJANG KUNING]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 04: Urban Sneakers Step & Street Lifestyle

* **Judul & Kategori Konten:** "Urban Daily Sneakers Walk & Street POV" — Kategori Footwear & Lifestyle
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Sepatu sneakers bertali putih dengan aksen suede abu-abu di bagian depan dan sol gum retro.
  * **Referensi 2 (Persona Model):** Kaki pria dengan celana chino cuff beige berjalan santai di trotoar perkotaan aesthetic.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Low-angle handheld tracking shot, 9:16] Feet walking at normal pace across clean textured asphalt and pedestrian crosswalk with sunlight reflections.
  [Jump cut to 3.5s-7.0s: 45-degree side angle slow-motion] Step landing firmly on ground, showing shoe arch support and pristine midsole cleanliness.
  [Jump cut to 7.0s-10.0s: Ground-level freeze-frame tilt up] Foot resting on a marble curb, clean shoe perspective toward camera with street background bokeh. Sony A7S III 35mm f/1.8, 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/43a847f3-4797-4aab-93f8-1757feec22bf](https://labs.google/fx/tools/flow/shared/video/43a847f3-4797-4aab-93f8-1757feec22bf)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Sepatu yang cocok buat lo yang aktif jalan 10.000 langkah tiap hari!"*  
    📌 **Teks Layar:** `SEPATU COCOK BUAT DAILY COMMUTE 🚶‍♂️`
  * `3.0s – 6.5s (Demo Fitur):` *"Insole empuk anti-pegal, desain timeless cocok dipadukan sama celana apapun!"*  
    📌 **Badge Layar:** `[👟 ERGONOMIC ARCH SUPPORT]`
  * `6.5s – 10.0s (CTA):` *"Lagi ada diskon gajian, klik keranjang kuning sekarang!"*  
    📌 **Grafis:** `[🛒 AMBIL DISKON GAJIAN DI SINI]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 05: Female Casual Outfit Mirror Selfie & Studio Transition

* **Judul & Kategori Konten:** "OOTD Mirror Selfie & Studio Try-On" — Kategori Women Fashion & OOTD
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Cardigan rajut lembut / atasan santai wanita dengan celana kulot flowy warna pastel.
  * **Referensi 2 (Persona Model):** Wanita muda Indonesia dengan ponsel di tangan melakukan mirror selfie di kamar aesthetic, tersenyum manis.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Eye-level mirror reflection shot, 9:16] Young female creator holding smartphone, posing gracefully in front of a full-length arch mirror with warm room lights.
  [Jump cut to 3.5s-7.0s: Smooth spin transition in photo studio] Model twirls softly against a clean pastel studio backdrop, showing how the fabric flows naturally.
  [Jump cut to 7.0s-10.0s: Close-up front smile] Creator smiles into the camera while giving a cute thumbs up and pointing down. 4k 60fps, soft ring-light illumination.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/a714f6b3-1f30-4d89-a44b-7008b83cf2aa](https://labs.google/fx/tools/flow/shared/video/a714f6b3-1f30-4d89-a44b-7008b83cf2aa)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Nemu lagi atasan rajut gemes yang bahannya super halus dan gak bikin gatal!"*  
    📌 **Teks Layar:** `SPILL ATASAN RAJUT AESTHETIC ✨`
  * `3.0s – 6.5s (Demo Fitur):` *"Rajutannya rapat premium, warna pastelnya bikin kulit keliatan lebih cerah!"*  
    📌 **Badge Layar:** `[🌸 PREMIUM SOFT KNIT - TIDAK MENERAWANG]`
  * `6.5s – 10.0s (CTA):` *"Jangan sampai kehabisan warna favoritmu, checkout di keranjang kuning ya!"*  
    📌 **Grafis:** `[👇 KLIK DISINI BUAT PILIH WARNA]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

## ⌚ BAGIAN 2: GADGET, TECH & LUXURY ACCESSORIES

### Skenario 06: Smartwatch AMOLED Dial & Strap Luxury Detail

* **Judul & Kategori Konten:** "Smartwatch AMOLED Dial & Strap Luxury Detail" — Kategori Aksesori & Gadget
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Smartwatch premium dengan bezel metalik stainless steel, layar AMOLED hitam pekat dengan grafik sporty dial, dan tali strap silikon/kulit bertekstur.
  * **Referensi 2 (Persona Model):** Tangan pria bersih terawat dengan kemeja kasual yang digulung rapi di pergelangan tangan, gaya review tangan (hand-model POV).
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Extreme macro 45-degree tilt shot, 9:16 vertical] Male wrist rotating slowly towards the camera in a moody modern executive desk setup. The smartwatch screen lights up showing crisp UI widgets.
  [Jump cut to 3.5s-7.0s: Top-down macro push-in] Finger gently swiping the touchscreen with fluid UI transition. Reflection of soft office lighting gliding across the beveled glass edge.
  [Jump cut to 7.0s-10.0s: Medium side wrist angle] Hand clenching gently to show the snug fit and premium strap buckle finish, tilting to camera with a pristine highlight sparkle. 8k photorealistic product commercial, 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/c661e143-46a1-431a-8c35-b43a651eac68](https://labs.google/fx/tools/flow/shared/video/c661e143-46a1-431a-8c35-b43a651eac68)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Kalian gak bakal nyangka kalau smartwatch sekeren ini harganya under 200 ribuan!"*  
    📌 **Teks Layar:** `SMARTWATCH MEWAH TAPI MURAH? ⌚✨`
  * `3.0s – 6.5s (Demo Fitur):` *"Layarnya udah AMOLED super jernih, full sensor kesehatan, dan baterai tahan 10 hari!"*  
    📌 **Badge Layar:** `[🔋 BATERAI 10 HARI + LAYAR AMOLED HD]`
  * `6.5s – 10.0s (CTA):` *"Garansi resmi 1 tahun, buruan amankan diskon flash sale-nya di keranjang kuning!"*  
    📌 **Grafis:** `[🛒 KLAIM VOUCHER DISKON DI KERANJANG KUNING]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 07: Wireless Clip-on Mic & Creator Audio Test

* **Judul & Kategori Konten:** "Wireless Mic Noise Cancelling Demonstration" — Kategori Creator Tech & Gadget
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Mic wireless clip-on kecil compact warna hitam matte dengan lampu indikator biru/hijau dan magnetic back clip.
  * **Referensi 2 (Persona Model):** Kreator konten pria memegang receiver dan menyematkan mic transmitter ke kerah kaos dengan gerakan percaya diri.
* **Master Action Prompt:**
  ```text
  [0.0s-3.0s: Medium close-up chest level, 9:16] Content creator clipping the compact wireless microphone onto his shirt collar, tapping the mic mesh twice with a confident smile.
  [Jump cut to 3.0s-6.5s: Extreme macro detail on mic body] Finger pressing the noise cancellation button, indicator light turns bright cyan green, showing crisp build texture.
  [Jump cut to 6.5s-10.0s: Dynamic wide pullback] Creator speaking with high energy, gesturing to camera with open palm and pointing toward the bottom corner. 4k 60fps clean studio lighting.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/54d6aade-4b79-4736-baab-7f8fdec9cfeb](https://labs.google/fx/tools/flow/shared/video/54d6aade-4b79-4736-baab-7f8fdec9cfeb)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Suara video lo masih berisik dan banyak kresek-kresek? Cobain mic ini!"*  
    📌 **Teks Layar:** `UPGRADE AUDIO KONTEN AUTO JERNIH 🎙️`
  * `3.0s – 6.5s (Demo Fitur):` *"Sekali klik tombol noise cancellation, suara bising di sekitar langsung hilang total!"*  
    📌 **Badge Layar:** `[🔇 ACTIVE NOISE REDUCTION CHIP]`
  * `6.5s – 10.0s (CTA):` *"Plug and play tanpa aplikasi tambahan, order sekarang di keranjang kuning!"*  
    📌 **Grafis:** `[👇 CHECKOUT DI KERANJANG SEBELUM HARGA NAIK]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 08: Premium Eyewear & Glasses Face Framing

* **Judul & Kategori Konten:** "Anti-Radiation Eyewear Aesthetic Framing" — Kategori Fashion & Accessories
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Kacamata frame titanium ringan dengan lensa anti-radiasi blue-light bening dengan pantulan semburat biru elegan.
  * **Referensi 2 (Persona Model):** Wanita/pria muda berwajah proporsional tersenyum anggun saat mengenakan kacamata ke wajahnya.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Close-up eye level, 9:16] Model holds the sleek eyeglasses by the temples and smoothly puts them on, adjusting the nose bridge with index finger.
  [Jump cut to 3.5s-7.0s: Macro 45-degree angle] Blue light reflection gracefully passing over the crystal-clear lens coating under studio key light.
  [Jump cut to 7.0s-10.0s: Portrait framing with confident glance] Model smiles warmly into the camera lens, showcasing how the frame accentuates facial contours. 85mm f/1.4 depth of field, 4k 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/62099c64-d9f2-465a-9c1b-bbabedbaa2d8](https://labs.google/fx/tools/flow/shared/video/62099c64-d9f2-465a-9c1b-bbabedbaa2d8)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Kacamata anti-radiasi yang bikin mata gak gampang lelah di depan laptop seharian!"*  
    📌 **Teks Layar:** `KACAMATA ANTI BLUE-LIGHT WAJIB PUNYA 👓💻`
  * `3.0s – 6.5s (Demo Fitur):` *"Framenya super ringan titanium lentur, gak bikin pusing atau berbekas di hidung!"*  
    📌 **Badge Layar:** `[🛡️ LENSA BLUE-RAY PROTECT + FRAME TITANIUM]`
  * `6.5s – 10.0s (CTA):` *"Dapat kotak kacamata kulit + lap gratis, klik keranjang kuning sekarang!"*  
    📌 **Grafis:** `[🛒 AMBIL BONUS FREE HARDCASE DI SINI]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

## 🚗 BAGIAN 3: AUTO-CARE & TECHNICAL ACTIONS

### Skenario 09: Car Hood Paint Restoration & Mirror Finish

* **Judul & Kategori Konten:** "Car Hood Paint Restoration & Mirror Finish" — Kategori Otomotif & ASMR Restoration
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Panel bodi mobil vintage / kap mesin berkarat kusam yang sedang dibersihkan menjadi kinclong berkilau cermin.
  * **Referensi 2 (Persona Model):** Mekanik profesional dengan sarung tangan karet hitam dan celemek kerja workshop, bekerja teliti dengan lap microfiber dan compound poles.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Eye-level dynamic close-up, 9:16] Mechanic wiping a heavily rusted vintage car hood with a specialized foam applicator. A clean shiny surface instantly revealed in a smooth swipe action.
  [Jump cut to 3.5s-7.0s: Macro angle on liquid compound] Spraying precision liquid nano-coating, creating water-beading hydrophobic effect that glides effortlessly off the surface under bright workshop neon lights.
  [Jump cut to 7.0s-10.0s: Low-angle tracking reflection shot] Mechanic standing back with hands on waist, admiring the flawless mirror-like paint reflection. High contrast cinematic garage aesthetic, Sony FX3 4k 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/425041b5-4565-43f6-8d3b-fb2a5e5f280b](https://labs.google/fx/tools/flow/shared/video/425041b5-4565-43f6-8d3b-fb2a5e5f280b)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Jangan buru-buru cat ulang mobil lo sebelum coba cairan pengkilap satu ini!"*  
    📌 **Teks Layar:** `RESTORE CAT KUSAM JADI KINCLONG DALAM 5 DETIK! 🚗✨`
  * `3.0s – 6.5s (Demo Fitur):` *"Cukup sekali usap, karat dan jamur langsung rontok plus ngasih efek daun talas permanen!"*  
    📌 **Badge Layar:** `[🛡️ NANO CERAMIC COATING + ANTI JAMUR]`
  * `6.5s – 10.0s (CTA):` *"Paket komplit dapat lap microfiber + spons, klik keranjang kuning sekarang!"*  
    📌 **Grafis:** `[👇 AMBIL PAKET PROMO SPESIAL DI KERANJANG]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 10: Precision Spray Coating & Workshop Action

* **Judul & Kategori Konten:** "Automotive Panel Primer & Airbrush Detailing" — Kategori Workshop & Detailing
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Spray gun cat otomotif profesional dengan kabut semprotan cat primer halus seragam ke permukaan logam.
  * **Referensi 2 (Persona Model):** Teknisi menggunakan masker respirator dan kacamata pelindung melakukan teknik semprotan horizontal konsisten.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Macro side profile, 9:16] Spray gun nozzle triggering, releasing a pristine uniform mist of primer paint onto a smooth car panel.
  [Jump cut to 3.5s-7.0s: High-speed 120fps slow-motion] Fine paint droplets settling evenly, transforming the metallic sheen into a perfect matte base coat.
  [Jump cut to 7.0s-10.0s: Medium workshop overview] Technician inspecting the smooth finish with an LED inspection light, nodding approvingly. Cinematic dramatic workshop lighting, 4k 60fps.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/8b27e1b7-3c34-418a-91f1-5cd9e3939e13](https://labs.google/fx/tools/flow/shared/video/8b27e1b7-3c34-418a-91f1-5cd9e3939e13)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Kunci hasil cat mobil mulus tanpa bintik ada di spray gun satu ini!"*  
    📌 **Teks Layar:** `CAT BODY SENDIRI HASIL BENGKEL PRO 🎨🛠️`
  * `3.0s – 6.5s (Demo Fitur):` *"Tekanan angin stabil, nozzle presisi bikin cat hemat sampai 40% tanpa boros!"*  
    📌 **Badge Layar:** `[⚡ HIGH VOLUME LOW PRESSURE - HEMAT CAT]`
  * `6.5s – 10.0s (CTA):` *"Alat wajib anak otomotif, checkout di keranjang kuning sekarang!"*  
    📌 **Grafis:** `[🛒 ORDER SPRAY GUN RESMI DISINI]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

## 🎙️ BAGIAN 4: CONTENT CREATOR, PODCAST & TALKING HEAD

### Skenario 11: Podcast Studio Talking Head & Revenue Breakdown

* **Judul & Kategori Konten:** "Podcast Studio Talking Head & Revenue Breakdown" — Kategori Digital Product & Agency
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Mikrofon podcast studio profesional / setup meja podcast minimalis dengan laptop dan headphone monitor.
  * **Referensi 2 (Persona Model):** Pria/Wanita kreator konten usia 25 tahun berpakaian rapi, berbicara natural menghadap mikrofon dengan lighting studio podcast bernuansa hangat.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Medium close-up eye level, 9:16 vertical] Creator speaking animatedly into a studio condenser microphone, using expressive hand gestures with authentic mouth and eye movements.
  [Jump cut to 3.5s-7.0s: Dynamic over-the-shoulder angle] Showing the laptop screen displaying digital product analytics, creator turning head smoothly back to camera with an insightful smile.
  [Jump cut to 7.0s-10.0s: Tight punch-in on face] Creator winks and points directly down towards screen boundary with high enthusiasm. Crisp vocal studio lighting, clean background bokeh, 4k 60fps creator aesthetic.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/271044d8-0bd7-46ac-ae2c-81f9432ae225](https://labs.google/fx/tools/flow/shared/video/271044d8-0bd7-46ac-ae2c-81f9432ae225)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Ini rahasia gimana gua bisa bikin 30 video jualan AI cuma dalam waktu 1 jam!"*  
    📌 **Teks Layar:** `BIKIN 30 VIDEO TIKTOK DALAM 1 JAM PAKE AI 🤯`
  * `3.0s – 6.5s (Demo Fitur):` *"Cukup input foto produk + copy prompt ini ke Google Flow, videonya langsung jadi otomatis tanpa repot rekam wajah!"*  
    📌 **Badge Layar:** `[⚡ 100% AUTOMATED WORKFLOW]`
  * `6.5s – 10.0s (CTA):` *"Template prompt lengkapnya udah gua siapin di ebook ini, klik link di bawah sekarang!"*  
    📌 **Grafis:** `[🚀 DOWNLOAD MASTER PROMPT EBOOK SEKARANG]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

### Skenario 12: Digital Product Affiliate Laptop Showcase

* **Judul & Kategori Konten:** "Laptop Workspace & Passive Income Dashboard" — Kategori Edukasi & Bisnis Digital
* **Setup Input Visual:**
  * **Referensi 1 (Produk):** Layar laptop modern menampilkan grafik penjualan digital produk dan dashboard Lynk.id / Tripay hijau profit.
  * **Referensi 2 (Persona Model):** Kreator muda sedang mengetik santai di coffee shop bernuansa hangat, menyeruput kopi lalu tersenyum ke arah laptop.
* **Master Action Prompt:**
  ```text
  [0.0s-3.5s: Over-the-shoulder medium shot, 9:16] Creator typing on MacBook keyboard in an aesthetic modern cafe with warm natural light pouring through large window.
  [Jump cut to 3.5s-7.0s: Screen close-up macro] Dashboard showing real-time incoming sales notifications and upward trending revenue charts.
  [Jump cut to 7.0s-10.0s: Eye-level portrait shot] Creator turns towards camera holding a coffee cup with an encouraging nod, pointing to the link below. 4k 60fps natural cinematic grade.
  ```
* **Link Dapur Proyek:** [https://labs.google/fx/tools/flow/shared/video/ef5fb52f-b875-44ca-bf9a-774ba6e62c56](https://labs.google/fx/tools/flow/shared/video/ef5fb52f-b875-44ca-bf9a-774ba6e62c56)
* **Naskah Audio & Motion Graphic:**
  * `0.0s – 3.0s (Hook):` *"Ternyata jualan file digital pake bantuan AI potensinya bisa segurih ini!"*  
    📌 **Teks Layar:** `HASILKAN CUAN DARI PRODUK DIGITAL AI 💰🚀`
  * `3.0s – 6.5s (Demo Fitur):` *"Tanpa perlu packing barang, tanpa modal stok, sistem kirim file-nya otomatis 24 jam!"*  
    📌 **Badge Layar:** `[📈 100% AUTOMATED DIGITAL DELIVERY]`
  * `6.5s – 10.0s (CTA):` *"Mau belajar alur lengkapnya dari nol? Gabung kelasnya lewat link di bio sekarang!"*  
    📌 **Grafis:** `[👉 GABUNG KELAS PRODUK DIGITAL DISINI]`
* **Parameter Teknis:** Durasi: 10 Detik | Aspek Rasio: 9:16 | Engine: Google Flow (Veo / Imagen 3 Node)

---

## 💡 BLUEPRINT ALUR PRODUKSI GOOGLE FLOW
1. **Pilih Skenario & Niche:** Tentukan model produk yang ingin dipromosikan (Sepatu / Fashion / Gadget / Edukasi).
2. **Generate Foto Pertama (Image Node):** Gunakan formula **Referensi 1 + Referensi 2** pada Google Flow Imagen 3 Node dengan rasio `9:16`.
3. **Generate Gerak Video (Video Node):** Sambungkan hasil foto ke Video Node (Veo) dan paste **Master Action Prompt** lengkap dengan penanda timestamp `[0.0s-3.0s]`, `[3.0s-6.5s]`, dan `[6.5s-10.0s]`.
4. **Ekspor & Monetisasi:** Lengkapi dengan audio naskah di atas untuk langsung dijual sebagai jasa video promosi atau dijadikan konten affiliate berdaya konversi tinggi.
